# ==============================================================================
# Title: Gene Count and Jaccard Index
# Author: Il-Hwan LEE
# ==============================================================================
# R 4.4.3 (arm64)
# ==============================================================================
# Load Libraries
library(dplyr) # v1.2.0
library(data.table) # v1.18.2.1
library(pheatmap) # v1.0.13

# ==============================================================================
# Define functions
# ==============================================================================

# 1. Function to modify uncertain tax levels-written as incertae sedis
fix_incertae_by_phylum <- function(df) {
  tax_levels <- c("Species", "Genus", "Family", "Order", "Class")
  
  df_final <- df %>%
    mutate(across(all_of(tax_levels), 
                  ~ ifelse(tolower(trimws(as.character(.))) == "incertae sedis",
                           paste0("Uncertain_", cur_column(), "_", as.character(Phylum)), 
                           as.character(.))))
  
  return(df_final)
}

# 2. Function to calculate jaccard index
jaccard <- function(a, b) {
  intersection <- length(intersect(a, b))
  union <- length(a) + length(b) - intersection
  return (intersection/union)
}

# ==============================================================================
# Environment & Data Setup
# ==============================================================================

# Setup directories
dir <- "/directory/to/data"
dir_analysis <- file.path(dir, "analysis")
dir_res <- file.path(dir_analysis, "results")
if(!dir.exists(dir_res)) dir.create(dir_res, recursive = TRUE, showWarnings = FALSE)

# Domain list
dom_list_fp <- file.path(dir, "protein_domains_hmm.csv")
dom_list <- read.table(dom_list_fp, header = F, stringsAsFactors = T)
colnames(dom_list) <- c("Class","Type","Family","Domains","homology_cluster","inflation","min_phylo_size")
dom_list_gap_ixs <- c(1,1+which(diff(as.numeric(dom_list$Type))!=0)) - 1

# Taxonomy information (taxonomy matched from new_taxdump.tar.gz)
sps_tax_fp <- file.path(dir, "Taxonomy_info.txt")
sps_tax <- read.table(sps_tax_fp, sep="\t", quote="\"", fill = T, header = T, comment.char = "", stringsAsFactors = F)
sps_tax <- fix_incertae_by_phylum(sps_tax) # fix uncertain information (Incertae sedis)

# Gene counts
gen <- fread(input = sprintf("%s/gene_counts/All.genecounts.csv", dir_analysis), data.table = F, header = F, col.names = c("Protein_id", "Protein_family"))
gen$Abbreviation <- sub("_.*", "", gen[, 1])
gen$Protein_family <- factor(gen$Protein_family, levels = unique(dom_list$Family))

# ==============================================================================
# Main - 1. Gene counts
# ==============================================================================

# Match gene counts with species taxonomy
gen_m <- merge(gen, sps_tax, by.x = "Abbreviation", by.y = "Abbreviation", all.x = T)

# Convert to gene presence table (one entry per species)
gen_u <- within(gen_m, rm("Protein_id"))
gen_u <- unique(gen_u)

# Create "counts" matrix (Phylum by Protein family)
phylum_list <- unique(data.frame(sps_tax$Phylum, sps_tax$Kingdom))
phylum_order <- phylum_list[,1]
phylum_gap_ixs <- c(1,1+which(diff(as.numeric(factor(phylum_list$sps_tax.Kingdom)))!=0)) - 1

gen_crosstab <- xtabs(formula = ~ Phylum + Protein_family, data = gen_u, drop.unused.levels	= F)
gen_crosstab <- as.data.frame.matrix(gen_crosstab)
gen_crosstab <- gen_crosstab[phylum_order, ] # row sort by phylum order

# Create "fraction" matrix
sps_counts_by_phylum <- table(factor(sps_tax$Phylum, levels=unique(sps_tax$Phylum))) # number of species per phylum
gen_crosstab_frac <- sweep(gen_crosstab, MARGIN = 1, sps_counts_by_phylum, "/")

# Column (protein family) sort by clustered pattern

TCA_names <- c("Citrate_synt", "Aconitase", "Iso_dh", "2-oxogl_dehyd", "FumaraseC_C")
GS_names <- c("Malate_synthase", "ICL")

TCA_pos <- match(TCA_names, names(gen_crosstab_frac)) # 1. fixed positions for TCA enzymes
GS_pos <- match(GS_names, names(gen_crosstab_frac)) # 2. fixed positions for GS enzymes

  ## --- a-1. cluster protein families ---
  doms_to_cluster <- gen_crosstab_frac[, setdiff(names(gen_crosstab_frac), c(TCA_names, GS_names))]
  
  dist_cols <- dist(t(doms_to_cluster))
  hc_cols <- hclust(dist_cols)
  
  ## --- a-2. generate dendogram to determine clusters ---
  dend <- as.dendrogram(hc_cols) # dendogram
  node_leaves <- partition_leaves(dend)
  node_pos <- get_nodes_xy(dend)
  nn <- nnodes(dend)
  is_leaf <- is.leaf(dend)
  
  plot(dend)
  text(node_pos, 
       labels = 1:nn, 
       adj = c(1.2, 1.2), 
       col = "blue", cex = 0.7)
  
  cluster_1 <- c(11,13,15,16,9,6,7,3)
  cluster_2 <- c(64,66,68,69)
  cluster_3 <- c(61,62,59,58,55)
  cluster_4 <- c(21,23,25,26)
  cluster_5 <- c(28,31,32,34,36,38,40,42,44,46,48,50,52,53)
  
  target_nodes <- c(cluster_1, cluster_2, cluster_3, cluster_4, cluster_5)
  target_names <- unlist(node_leaves[target_nodes])

reordered_pos <- match(target_names, names(gen_crosstab_frac)) # 3. reordered positions for other protein families

gen_crosstab <- gen_crosstab[,c(TCA_pos, GS_pos, reordered_pos)] # reorder matrix
gen_crosstab_frac <- gen_crosstab_frac[,c(TCA_pos, GS_pos, reordered_pos)] # reorder matrix

# Save matrix (CSVs)
write.csv(gen_crosstab, file=sprintf("%s/Count_matrix.csv", dir_res), row.names = T, quote = F)
write.csv(gen_crosstab_frac, file=sprintf("%s/Fraction_matrix.csv", dir_res), row.names = T, quote = F)

# Heatmap
col_heatmap <- colorRampPalette(interpolate="l",c("gray90", "goldenrod1","firebrick2","darkred"))

pdf(file=sprintf("%s/Fraction_matrix_heatmap.pdf", dir_res), height=10,width=10)
pheatmap(gen_crosstab_frac, color = col_heatmap(20), breaks = c(0,0.0001,seq(0.05,1,length.out = 19)), 
         gaps_col = c(length(TCA_pos), length(c(TCA_pos, GS_pos))),
         gaps_row = phylum_gap_ixs,
         cellwidth = 5, cellheight = 5, fontsize = 5,
         border_color = "white", cluster_cols=F, cluster_rows=F, display_numbers = F)
dev.off()

# Save number of species per phylum (CSVs, Bar Graph)
write.csv(sps_counts_by_phylum, file=sprintf("%s/Species_count_per_phylum.csv", dir_res), row.names = F, quote = F)

pdf(file=sprintf("%s/Species_count_per_phylum.pdf", dir_res), height=5,width=10)
barplot(sps_counts_by_phylum, 
        las=2, border = NA, cex.names = 0.5,
        main="# of species per phylum")
dev.off()

# ==============================================================================
# Main - 2. Jaccard index
# ==============================================================================

tax_rank <- c("Phylum", "Kingdom", "Superkingdom")
base_domains <- c("ICL", "Tet_JBP")
target_list <- as.character(dom_list$Family)

for (rank in tax_rank) {
  name_list = as.character(unique(sps_tax[,rank]))
  
  # matrix to store result
  target_mat_list <- list(
    ICL = matrix(ncol = length(target_list) - 1, nrow = 0), # exclude itself -1
    Tet_JBP = matrix(ncol = length(target_list) - 1, nrow = 0)
  )
  rowname_list <- list(ICL = c(), Tet_JBP = c())
  
  for (name in name_list) {
    sub_sps_tax <- sps_tax[sps_tax[,rank] == name, ]
    sub_gen_m <- gen_m[gen_m[,rank] == name, ]
    
    if (nrow(sub_gen_m) == 0) next
    
    sub_gen_m$Taxonomy_name_factor <- factor(sub_gen_m$Taxonomy_name, levels = unique(sub_sps_tax$Taxonomy_name))
    sub_gen_u <- unique(within(sub_gen_m, rm("Protein_id")))
    
    gen_crosstab_jacc <- xtabs(formula = ~ Protein_family + Taxonomy_name_factor, data = sub_gen_u, drop.unused.levels = F)
    gen_crosstab_jacc[gen_crosstab_jacc > 1] <- 1
    
    # calculate jaccard overlap score
    for (base_dom in base_domains) {
      
      # remove base_domain from target list
      curr_targets <- setdiff(target_list, base_dom) 
      
      if (base_dom %in% rownames(gen_crosstab_jacc)) {
        tax_with_base <- colnames(gen_crosstab_jacc)[ gen_crosstab_jacc[base_dom, ] > 0 ]
        
        jac_scores <- unlist(lapply(curr_targets, function(target) { 
          if (target %in% rownames(gen_crosstab_jacc)) {
            tax_with_target <- colnames(gen_crosstab_jacc)[ gen_crosstab_jacc[target, ] > 0 ]
            return(jaccard(tax_with_base, tax_with_target))
          } else {
            return(0)
          }
        }))
        names(jac_scores) <- curr_targets
        
        # store results
        rowname_list[[base_dom]] <- c(rowname_list[[base_dom]], name)
        target_mat_list[[base_dom]] <- rbind(target_mat_list[[base_dom]], jac_scores)
      }
    }
  }
  
  # Save results (CSVs, Bar Graphs)
  for (base_dom in base_domains) {
    
    mat <- target_mat_list[[base_dom]]
    
    if(nrow(mat) == 0) next
    
    rownames(mat) <- rowname_list[[base_dom]]
    colnames(mat) <- setdiff(target_list, base_dom)
    mat <- na.omit(mat)
    
    write.table(mat, file=sprintf("%s/Jaccard_index_%s_%s_matrix.csv", dir_res, rank, base_dom), row.names = T, col.names = NA, quote = F, sep = "\t")
    
    # Barplots
    pdf(file=sprintf("%s/Jaccard_index_%s_%s_barplot.pdf", dir_res, rank, base_dom), width = 4, height = 6)
    for (tax_name in row.names(mat)) {
      
      sub_vec <- mat[tax_name, ]
      sub_vec <- sort(sub_vec, decreasing = FALSE) 
      
      par(mgp=c(1,0.5,0), mar=c(5,4,4,2)+0.1)
      barplot(sub_vec, horiz = T, las=2, col = rainbow(n = 1, start = 0.1, end = 0.85, v = 0.9), cex.names=0.3, cex.axis = 0.6, xlab = "Jaccard index", cex.lab=0.6)
      title(main=sprintf("Jaccard overlap scores (%s)\nSimilarity between the %s-level distribution of %s with other domains", tax_name, rank, base_dom), cex.main=0.6)
    }
    dev.off()
  }
}

